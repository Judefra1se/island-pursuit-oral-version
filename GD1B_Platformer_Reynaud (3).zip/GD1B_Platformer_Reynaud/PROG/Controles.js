export class Controles extends Phaser.Scene {
    constructor() {
        super("Controles");
    }

    //FONCTION PRELOAD
    preload() {
        this.load.image("controles", "controles.png")
    }

    create() {
                
            this.add.image(448, 224, "controles")
            this.clavier = this.input.keyboard.addKeys('ENTER');

    }

    update(){
     if (this.clavier.ENTER.isDown) {
            this.cameras.main.fadeOut(1000, 0, 0, 0)
            this.time.addEvent({
                delay: 800, callback: () => {
                    this.scene.start("SceneSeau")
                },
            })
                


        }
    }
}